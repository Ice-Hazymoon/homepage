/*
 * File: config.js
 * Project: router
 * File Created: Thursday, 21st June 2018 2:48:10 pm
 * Author: Ice-Hazymoon (imiku.me@gmail.com)
 * -----
 * Last Modified: Thursday, 21st June 2018 2:49:14 pm
 * Modified By: Ice-Hazymoon (imiku.me@gmail.com)
 * -----
 * Copyright 2017 - 2018
 */
import default_config from "./assets/data";
export default default_config